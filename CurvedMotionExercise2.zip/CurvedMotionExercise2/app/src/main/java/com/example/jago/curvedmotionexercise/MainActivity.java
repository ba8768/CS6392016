package com.example.jago.curvedmotionexercise;

import android.annotation.TargetApi;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Scene;
import android.transition.TransitionInflater;
import android.transition.TransitionManager;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {
    ViewGroup layout;
    Scene scene1;
    public static boolean count;
    public int count2;
    Scene scene2;
    TransitionManager transitionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        count2 =2;
        layout = (ViewGroup) findViewById(R.id.relativeLayoutId);
        layout.setOnTouchListener(

        new RelativeLayout.OnTouchListener(){

            @Override
                    public boolean onTouch(View v, MotionEvent event) {
                    count2++;
                        moveThePic();

                        System.out.println(count);
                        return true;
                    }
                }
        );
    }


    @TargetApi(Build.VERSION_CODES.KITKAT)
    public void moveThePic(){
        scene1 = Scene.getSceneForLayout(layout, R.layout.scene2,this);
        scene2 = Scene.getSceneForLayout(layout, R.layout.activity_main,this);


        RelativeLayout.LayoutParams position = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);


        View re = findViewById(R.id.buttonId);
        if (count2%2==0){
            count=true;
        }else{
            count=false;
        }

        TransitionManager.beginDelayedTransition(layout);
        if (count) {
            position.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
            position.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);

            re.setLayoutParams(position);
        }
        else{
            position.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
            position.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);

            re.setLayoutParams(position);
        }
    }

}
