package com.example.jago.curvedmotionexercise;

import android.support.v4.app.Fragment;

/**
 * Created by JaGo on 6/28/16.
 */
public class MainAcitivity2 extends Fragment {

}
