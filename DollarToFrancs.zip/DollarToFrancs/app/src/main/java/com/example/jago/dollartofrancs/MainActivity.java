package com.example.jago.dollartofrancs;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button zero, one, two, three, four, five, six, seven, eight,nine, dot, eval,clear;
    EditText text;
    TextView answer;
    static String dollar ="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });


        zero= (Button) findViewById(R.id.btZero);
        one=(Button) findViewById(R.id.btOne);
        two=(Button) findViewById(R.id.btTwo);
        three=(Button) findViewById(R.id.btThree);
        four=(Button) findViewById(R.id.btFour);
        five=(Button) findViewById(R.id.btFive);
        six=(Button) findViewById(R.id.btSix);
        seven=(Button) findViewById(R.id.btSeven);
eight=(Button) findViewById(R.id.btEight);
        nine=(Button) findViewById(R.id.btNine);
        dot=(Button) findViewById(R.id.btDot);
        eval=(Button)findViewById(R.id.btEval);
        text= (EditText) findViewById(R.id.editText);
        answer= (TextView) findViewById(R.id.textView2);
        clear = (Button) findViewById(R.id.btClear);

        clear.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                dollar="";
                text.setText("");
                answer.setText("Amount will appear here!");

            }
        });

        zero.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                dollar=dollar+"0";
                text.setText(dollar);

            }
        });
        one.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                dollar=dollar+"1";
                text.setText(dollar);


            }
        });
        two.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                dollar=dollar+"2";
                text.setText(dollar);

            }
        });
        three.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                dollar=dollar+"3";
                text.setText(dollar);

            }
        });
        four.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                dollar=dollar+"4";
                text.setText(dollar);

            }
        });five.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                dollar=dollar+"5";
                text.setText(dollar);

            }
        });six.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                dollar=dollar+"6";
                text.setText(dollar);

            }
        });seven.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                dollar=dollar+"7";
                text.setText(dollar);

            }
        });eight.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                dollar=dollar+"8";
                text.setText(dollar);

            }
        });nine.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                dollar=dollar+"9";
                text.setText(dollar);

            }
        });dot.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                dollar=dollar+".";
                text.setText(dollar);

            }
        });eval.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                convert(dollar);

            }
        });
    }
    public void convert(String dollar3){
        Double dollarDouble = Double.parseDouble(dollar3);
        double answerr=  (dollarDouble * 439.36);
        String textInput = answerr +"";
        answer.setText(textInput + " Comorian francs.");
        dollarDouble =0.0;
        textInput="0.0";
        text.setText("");
        dollar = "";
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
